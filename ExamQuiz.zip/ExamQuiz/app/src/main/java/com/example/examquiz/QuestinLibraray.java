package com.example.examquiz;

public class QuestinLibraray {

    private String mQuestions [] = {
            "Which part of the palnts holds it in the soil?",
            "This part of the plant absorbs energy from the sun ?",
            "This part of the plant attracts bees, butterflies and humminghum",
            "The holds the plant upright"
    };

    private  String mChoice [][]  = {

            {"Roots", "Stem", "Flower"},
            {"Fruits", "Leaves", "Seeds"},
            {"Bark", "Flower", "Roots"},
            {"Fruits", "Leaves", "Seeds"},

    };

    private  String mCorrectAnswers [] ={
            "Roots",
            "Leaves","Flower","Seeds"
    };

    public  String getQuestion(int a) {
        String Question = mQuestions[a];
        return Question;
    }

    public String getChoice1(int a) {
        String choice1 = mChoice[a][0];
        return  choice1;
    }

    public String getChoice2(int a) {
        String choice2 = mChoice[a][1];
        return  choice2;
    }
    public String getChoice3(int a) {
        String choice3= mChoice[a][2];
        return  choice3;
    }

    public int getCorrectAnswer(int a) {
         return a;
    }
}
