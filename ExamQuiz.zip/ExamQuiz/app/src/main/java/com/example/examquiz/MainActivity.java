package com.example.examquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private QuestinLibraray mQuestionLibrary = new QuestinLibraray();
    private TextView mScoreView;
    private TextView mQuestionView;

    private String mAnswer;
    private  int mScore=0;
    private int mQuestionNumber=0;

    private  Button mBtnChoice1,mBtnChoice2,mBtnChoice3, mQuit;

    private void updateScore(int point) {
        mScoreView.setText("Score: "+ point);
    }

    private void updateQuestion() {
        mQuestionView.setText(mQuestionLibrary.getQuestion(1));
        mBtnChoice1.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        mBtnChoice2.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        mBtnChoice3.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mScoreView = findViewById(R.id.testScore);
        mQuestionView = findViewById(R.id.tvQuestion);
        mBtnChoice1 = findViewById(R.id.btnChoice1);
        mBtnChoice2 = findViewById(R.id.btnChoice2);
        mBtnChoice3 = findViewById(R.id.btnChoice3);

        mBtnChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mBtnChoice1.getText() == mAnswer) {

                    }
                    updateQuestion();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,"Something went wring", Toast.LENGTH_LONG).show();
                }
            }
        });


    }


}